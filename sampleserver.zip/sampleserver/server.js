var mysql = require('mysql2');
var express = require('express');

var app = express();
const port = 8081;

var bodyParser = require('body-parser');
app.use(bodyParser.json());       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
   extended: true
}));

var server = app.listen(port, function () {
   var host = server.address().address;
   var port = server.address().port;

   console.log("Example app listening at http://%s:%s", host, port);

});

app.set('view engine', 'ejs');

// route def
app.get('/', function (req, res) {
   res.send('Hello World');
});

app.get('/delete/:emailid', function (req, res) {
   let con = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "1234",
      database: "asw"
   });

   let emailid = req.params.emailid;
   con.connect(function (err) {
      if (err) throw err;
      console.log("Connected!");

      var sql1 = "DELETE FROM STUDENT where emailid = '" + emailid + "'";
      con.query(sql1, function (err, result) {
         if (err) throw err;
         console.log("DELETED : " + emailid)
         con.end()
      });

   });

   res.redirect("http://localhost:8081/read");
})

app.get('/read', function (req, res) {
   let con = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "1234",
      database: "asw"
   });

   con.connect(function (err) {
      if (err) throw err;
      console.log("Connected!");
      var sql0 = "SELECT * FROM STUDENT";
      con.query(sql0, function (err, result) {
         if (err) throw err;
         console.log(result);
         res.render('results', { results: result });
         con.end()
      });

   });

});

app.get('/new', function (req, res) {
   res.render('new');
});

app.post('/insert', function (req, res) {
   let name = req.body.name;
   let age = req.body.age;
   let emailid = req.body.emailid;

   console.log(name);
   console.log(age);
   console.log(emailid);

   let con = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "1234",
      database: "asw"
   });


   con.connect(function (err) {
      if (err) throw err;
      console.log("Connected!");

      var sql1 = "INSERT INTO STUDENT VALUES('" + name + "'," + age + ",'" + emailid + "')";
      con.query(sql1, function (err, result) {
         if (err) throw err;
         console.log("INSERTED")
         con.end()
      });

   });

   res.redirect("http://localhost:8081/read");

});

app.get('/edit/:emailid', function (req, res) {
   let con = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "1234",
      database: "asw"
   });
   let emailid = req.params.emailid;
   con.connect(function (err) {
      if (err) throw err;
      console.log("DB Connected for Edit Screen");
      var sql0 = "SELECT * FROM STUDENT where emailid = '" + emailid + "'";
      console.log(sql0);
      con.query(sql0, function (err, result) {
         if (err) throw err;
         console.log("Edit Query Result: ")
         console.log(result);
         if (result.length > 0)
            res.render('edit', { results: result[0] });
         else
            res.redirect("http://localhost:8081/read");
         con.end()
      });

   });
});

app.post('/update', function (req, res) {
   let name = req.body.name;
   let age = req.body.age;
   let emailid = req.body.emailid;
   console.log(name);
   console.log(age);
   console.log(emailid);

   let con = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "1234",
      database: "asw"
   });


   con.connect(function (err) {
      if (err) throw err;
      console.log("Connected!");

      var sql1 = "Update student set name = '" + name + "',age = " + age + " where emailid = '" + emailid + "'";
      con.query(sql1, function (err, result) {
         if (err) throw err;
         console.log("UPDATED")
         con.end()
      });

   });

   res.redirect("http://localhost:8081/read");

});